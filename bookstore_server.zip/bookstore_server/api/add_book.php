<?php

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

require_once('../config/database.php');

$data = json_decode(file_get_contents("php://input"), true);

// Validate required data
if (!isset($data['title'], $data['author'], $data['description'], $data['price'], $data['category'], $data['long_description'])) {
    echo json_encode(["status" => "error", "message" => "Invalid input data"]);
    exit;
}

$title = $data['title'];
$author = $data['author'];
$description = $data['description'];
$price = $data['price'];
$category = $data['category'];
$long_description = $data['long_description'];  // Get long description

// Prepare SQL query to insert data
$query = $conn->prepare("INSERT INTO books (title, author, description, price, category, long_description) 
                        VALUES (?, ?, ?, ?, ?, ?)");
if (!$query) {
    echo json_encode(["status" => "error", "message" => "Query preparation failed: " . $conn->error]);
    exit;
}

// Bind parameters for the query
$query->bind_param("ssssds", $title, $author, $description, $price, $category, $long_description);

if ($query->execute()) {
    echo json_encode(["status" => "success", "message" => "Book added successfully"]);
} else {
    echo json_encode(["status" => "error", "message" => "Query execution failed: " . $query->error]);
}

$conn->close();
?>
