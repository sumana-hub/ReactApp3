<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

require_once('../config/database.php');

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$response = [];

if ($id) {
    $stmt = $conn->prepare("SELECT * FROM books WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $book = $result->fetch_assoc();

    if ($book) {
        $response = [
            'success' => true,
            'book' => $book
        ];
    } else {
        $response = [
            'success' => false,
            'message' => 'Book not found'
        ];
    }
} else {
    $response = [
        'success' => false,
        'message' => 'Invalid book ID'
    ];
}

echo json_encode($response);
?>
