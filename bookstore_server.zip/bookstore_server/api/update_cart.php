<?php

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

require_once('../config/database.php');

$data = json_decode(file_get_contents("php://input"), true);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $data['user_id'];
    $book_id = $data['book_id'];
    $quantity = $data['quantity'];

    if (empty($user_id) || empty($book_id) || empty($quantity)) {
        echo json_encode(['success' => false, 'message' => 'User ID, Book ID, and quantity are required']);
        exit;
    }

    $stmt = $conn->prepare("UPDATE cart SET quantity = ? WHERE user_id = ? AND book_id = ?");
    $stmt->bind_param("iii", $quantity, $user_id, $book_id);
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Cart updated successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to update cart']);
    }
}
?>
