<?php

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

require_once('../config/database.php');

$limit = 6;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

$query = $conn->query("SELECT * FROM books LIMIT $limit OFFSET $offset");
$books = $query->fetch_all(MYSQLI_ASSOC);

$totalBooks = $conn->query("SELECT COUNT(*) AS total FROM books")->fetch_assoc()['total'];
$totalPages = ceil($totalBooks / $limit);

echo json_encode(["books" => $books, "totalPages" => $totalPages]);
?>
