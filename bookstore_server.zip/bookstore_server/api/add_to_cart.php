<?php

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

require_once('../config/database.php');

$data = json_decode(file_get_contents("php://input"), true);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $data['user_id'];
    $book_id = $data['book_id'];
    $quantity = $data['quantity'] ?? 1;

    if (empty($user_id) || empty($book_id) || empty($quantity)) {
        echo json_encode(['success' => false, 'message' => 'User ID, Book ID, and quantity are required']);
        exit;
    }

    // Check if the book already exists in the cart
    $stmt = $conn->prepare("SELECT id, quantity FROM cart WHERE user_id = ? AND book_id = ?");
    $stmt->bind_param("ii", $user_id, $book_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Update the quantity if the book already exists
        $stmt = $conn->prepare("UPDATE cart SET quantity = quantity + ? WHERE user_id = ? AND book_id = ?");
        $stmt->bind_param("iii", $quantity, $user_id, $book_id);
        $stmt->execute();
        echo json_encode(['success' => true, 'message' => 'Cart updated successfully']);
    } else {
        // Insert a new item into the cart
        $stmt = $conn->prepare("INSERT INTO cart (user_id, book_id, quantity) VALUES (?, ?, ?)");
        $stmt->bind_param("iii", $user_id, $book_id, $quantity);
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Book added to cart']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to add book to cart']);
        }
    }
}
?>
