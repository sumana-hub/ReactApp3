<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

require_once('../config/database.php');

// Retrieve the book ID and the action (like or dislike)
$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data['id'], $data['action'])) {
    echo json_encode(["status" => "error", "message" => "Invalid input data"]);
    exit;
}

$id = $data['id'];
$action = $data['action'];

// Update the like or dislike count
if ($action == 'like') {
    $query = $conn->prepare("UPDATE books SET like_count = like_count + 1 WHERE id = ?");
} elseif ($action == 'dislike') {
    $query = $conn->prepare("UPDATE books SET dislike_count = dislike_count + 1 WHERE id = ?");
} else {
    echo json_encode(["status" => "error", "message" => "Invalid action"]);
    exit;
}

$query->bind_param("i", $id);
if ($query->execute()) {
    echo json_encode(["status" => "success", "message" => "Like/Dislike updated successfully"]);
} else {
    echo json_encode(["status" => "error", "message" => "Query execution failed: " . $query->error]);
}

$conn->close();
?>
